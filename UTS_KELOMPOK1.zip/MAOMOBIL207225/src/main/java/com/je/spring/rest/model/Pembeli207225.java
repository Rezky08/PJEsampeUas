/*
 Kelompok 1 = Rezky(20)-Ravi(72)-Alfan(25) 
 */
package com.je.spring.rest.model;

public class Pembeli207225 {
    private int id207225;
    private String nik207225;
    private String namaPembeli207225;
    private String alamatPembeli207225;
    private String telpPembeli207225;

    public int getId207225() {
        return id207225;
    }

    public void setId207225(int id207225) {
        this.id207225 = id207225;
    }

    public String getNik207225() {
        return nik207225;
    }

    public void setNik207225(String nik207225) {
        this.nik207225 = nik207225;
    }

    public String getNamaPembeli207225() {
        return namaPembeli207225;
    }

    public void setNamaPembeli207225(String namaPembeli207225) {
        this.namaPembeli207225 = namaPembeli207225;
    }

    public String getAlamatPembeli207225() {
        return alamatPembeli207225;
    }

    public void setAlamatPembeli207225(String alamatPembeli207225) {
        this.alamatPembeli207225 = alamatPembeli207225;
    }

    public String getTelpPembeli207225() {
        return telpPembeli207225;
    }

    public void setTelpPembeli207225(String telpPembeli207225) {
        this.telpPembeli207225 = telpPembeli207225;
    }


    
    
}
