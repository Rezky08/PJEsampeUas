/*
 Kelompok 1 = Rezky(20)-Ravi(72)-Alfan(25) 
 */
package com.je.spring.rest.model;

public class Mobil207225 {

    private int id207225;
    private String namaMobil207225;
    private String merk207225;
    private String type207225;
    private String warna207225;
    private int harga207225;

    public String getNamaMobil207225() {
        return namaMobil207225;
    }

    public void setNamaMobil207225(String namaMobil207225) {
        this.namaMobil207225 = namaMobil207225;
    }

    public int getId207225() {
        return id207225;
    }

    public void setId207225(int id207225) {
        this.id207225 = id207225;
    }

    public String getMerk207225() {
        return merk207225;
    }

    public void setMerk207225(String merk207225) {
        this.merk207225 = merk207225;
    }

    public String getType207225() {
        return type207225;
    }

    public void setType207225(String type207225) {
        this.type207225 = type207225;
    }

    public String getWarna207225() {
        return warna207225;
    }

    public void setWarna207225(String warna207225) {
        this.warna207225 = warna207225;
    }

    public int getHarga207225() {
        return harga207225;
    }

    public void setHarga207225(int harga207225) {
        this.harga207225 = harga207225;
    }

}
