/*
  Kelompok 1 = Rezky(20)-Ravi(72)-Alfan(25) 
*/
package com.je.spring.rest.model;

public class Pegawai207225 {
    private int id207225;
    private String nik207225;
    private String namaPegawai207225;
    private String alamatPegawai207225;
    private String telpPegawai207225;

    public int getId207225() {
        return id207225;
    }

    public void setId207225(int id207225) {
        this.id207225 = id207225;
    }

    public String getNik207225() {
        return nik207225;
    }

    public void setNik207225(String nik207225) {
        this.nik207225 = nik207225;
    }

    public String getNamaPegawai207225() {
        return namaPegawai207225;
    }

    public void setNamaPegawai207225(String namaPegawai207225) {
        this.namaPegawai207225 = namaPegawai207225;
    }

    public String getAlamatPegawai207225() {
        return alamatPegawai207225;
    }

    public void setAlamatPegawai207225(String alamatPegawai207225) {
        this.alamatPegawai207225 = alamatPegawai207225;
    }

    public String getTelpPegawai207225() {
        return telpPegawai207225;
    }

    public void setTelpPegawai207225(String telpPegawai207225) {
        this.telpPegawai207225 = telpPegawai207225;
    }
    
    
}
