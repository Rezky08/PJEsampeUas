/*
 Kelompok 1 = Rezky(20)-Ravi(72)-Alfan(25) 
 */
package com.je.spring.rest.model;
import java.util.Date;


public class BeliCash207225 {
    private int id207225;
    private String cashTgl207225;
    private int cashBayar2072225;
    private Mobil207225 mobil207225;
    private Pegawai207225 pegawai207225;
    private Pembeli207225 pembeli207225;

    public int getId207225() {
        return id207225;
    }

    public void setId207225(int id207225) {
        this.id207225 = id207225;
    }

    public String getCashTgl207225() {
        return cashTgl207225;
    }

    public void setCashTgl207225(String cashTgl207225) {
        this.cashTgl207225 = cashTgl207225;
    }
    
    public int getCashBayar2072225() {
        return cashBayar2072225;
    }

    public void setCashBayar2072225(int cashBayar2072225) {
        this.cashBayar2072225 = cashBayar2072225;
    }

    

    public Mobil207225 getMobil207225() {
        return mobil207225;
    }

    public void setMobil207225(Mobil207225 mobil207225) {
        this.mobil207225 = mobil207225;
    }

    public Pegawai207225 getPegawai207225() {
        return pegawai207225;
    }

    public void setPegawai207225(Pegawai207225 pegawai207225) {
        this.pegawai207225 = pegawai207225;
    }

    public Pembeli207225 getPembeli207225() {
        return pembeli207225;
    }

    public void setPembeli207225(Pembeli207225 pembeli207225) {
        this.pembeli207225 = pembeli207225;
    }
    
    
    
}
