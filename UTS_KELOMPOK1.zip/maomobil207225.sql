﻿# SQL-Front 5.1  (Build 4.16)

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE */;
/*!40101 SET SQL_MODE='NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES */;
/*!40103 SET SQL_NOTES='ON' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;


# Host: localhost    Database: maomobil207225
# ------------------------------------------------------
# Server version 5.5.5-10.4.11-MariaDB

USE `maomobil207225`;

#
# Source for table beli_cash207225
#

DROP TABLE IF EXISTS `beli_cash207225`;
CREATE TABLE `beli_cash207225` (
  `Id207225` int(11) NOT NULL AUTO_INCREMENT,
  `cashTgl207225` datetime DEFAULT NULL,
  `cashBayar207225` bigint(20) DEFAULT NULL,
  `idPegawai207225` varchar(255) DEFAULT NULL,
  `idPembeli207225` varchar(255) DEFAULT NULL,
  `idMobil207225` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id207225`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

#
# Dumping data for table beli_cash207225
#

LOCK TABLES `beli_cash207225` WRITE;
/*!40000 ALTER TABLE `beli_cash207225` DISABLE KEYS */;
INSERT INTO `beli_cash207225` VALUES (1,'2020-04-22 19:00:48',20000,'1','1','6');
/*!40000 ALTER TABLE `beli_cash207225` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table mobil207225
#

DROP TABLE IF EXISTS `mobil207225`;
CREATE TABLE `mobil207225` (
  `Id207225` int(11) NOT NULL AUTO_INCREMENT,
  `namaMobil207225` varchar(255) DEFAULT NULL,
  `merk207225` varchar(255) DEFAULT NULL,
  `type207225` varchar(255) DEFAULT NULL,
  `warna207225` varchar(255) DEFAULT NULL,
  `harga207225` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`Id207225`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

#
# Dumping data for table mobil207225
#

LOCK TABLES `mobil207225` WRITE;
/*!40000 ALTER TABLE `mobil207225` DISABLE KEYS */;
INSERT INTO `mobil207225` VALUES (1,'Terios','Daihatsu','SUV','Merah',206800000);
INSERT INTO `mobil207225` VALUES (6,'Terios','Daihatsu','SUV','Merah',206800001);
/*!40000 ALTER TABLE `mobil207225` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table pegawai207225
#

DROP TABLE IF EXISTS `pegawai207225`;
CREATE TABLE `pegawai207225` (
  `Id207225` int(11) NOT NULL AUTO_INCREMENT,
  `nik207225` varchar(20) NOT NULL,
  `namaPegawai207225` varchar(255) DEFAULT NULL,
  `alamatPegawai207225` text DEFAULT NULL,
  `telpPegawai207225` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Id207225`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

#
# Dumping data for table pegawai207225
#

LOCK TABLES `pegawai207225` WRITE;
/*!40000 ALTER TABLE `pegawai207225` DISABLE KEYS */;
INSERT INTO `pegawai207225` VALUES (1,'3174102211990008','Rezky Setiawan','Jl.M.Saidi Raya RT 07/06 Petukangan Selatan Jakarta Selatan','089629238997');
/*!40000 ALTER TABLE `pegawai207225` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table pembeli207225
#

DROP TABLE IF EXISTS `pembeli207225`;
CREATE TABLE `pembeli207225` (
  `Id207225` int(11) NOT NULL AUTO_INCREMENT,
  `nik207225` varchar(20) NOT NULL,
  `namaPembeli207225` varchar(255) DEFAULT NULL,
  `alamatPembeli207225` text DEFAULT NULL,
  `telpPembeli207225` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Id207225`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

#
# Dumping data for table pembeli207225
#

LOCK TABLES `pembeli207225` WRITE;
/*!40000 ALTER TABLE `pembeli207225` DISABLE KEYS */;
INSERT INTO `pembeli207225` VALUES (1,'3174102211990008','Rezky Setiawan','Jl.M.Saidi Raya RT 07/06 Petukangan Selatan Jakarta Selatan','089629238998');
/*!40000 ALTER TABLE `pembeli207225` ENABLE KEYS */;
UNLOCK TABLES;

/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
